// import the modules needed
const express= require('express');
const path=require('path'); // in case we need to create a diff path
const fileupload = require('express-fileupload');
// steps for adding login/logout
const session = require('express-session');

// import mongoose library
const mongoose = require('mongoose');

// set up expess validator
const {check, validationResult} = require('express-validator');

// set up variables myApp, to use packages
// create express app
var myApp=express();

// connect to the database
mongoose.connect('mongodb://localhost:27017/Maintenance');

//define the models 
// models are the collection mappings in mongoDB
const Order = mongoose.model('Order', {
    name: String,
    email: String,
    photoName: String,
    mytextarea:String
    // please note above the its not photo but photoName

});
// create a model for admin users
const AdminUser = mongoose.model('AdminUser',{
    username: String,
    password: String
});


// set up body parser

myApp.use(express.urlencoded({extended:false}));


// set path to public folders and view folders

myApp.set('views', path.join(__dirname, 'views'));
//use public folder for CSS etc.
myApp.use(express.static(__dirname+'/public'));
myApp.set('view engine', 'ejs');

myApp.use(fileupload());

myApp.use(session({
    secret: 'abcdbookhub1234', // should be unique for each application
    resave: false,
    saveUninitialized: true
})); 


// routes (pages of the website)
// homepage
myApp.get('/',function(req,res){

    res.render('home'); // will go to home.ejs  and no need to put .ejs here near form
});




myApp.get('/logout',function(req, res){
    req.session.username = ''; // reset the username
    req.session.loggedIn = false; // make logged in false from true
    res.redirect('/login');
});

// 
myApp.post('/process',[
    check('name','Please enter name').notEmpty(),
    check('email','Please enter email').isEmail(),
    
    ], function(req,res){
    
      //fetch data
        var name = req.body.name;
        var email = req.body.email; 
        var mytextarea= req.body.mytextarea;
        // fetch the image
        var photo = req.files.photo;
    
        // fetch the image name
        var photoName = req.files.photo.name;
        var imagePath = 'public/uploads/' + photoName;
        photo.mv(imagePath);
    
      //process data
      const errors = validationResult(req);
      if(!errors.isEmpty()){ // if there are errors
        
        var errorData = errors.array();
        
        res.render('home', {errors: errorData});
        }
        else{
            // send data to confirmation page.. we create an object with name pageData
     
            var pageData = {
                name: name,
                email: email,
                mytextarea:mytextarea,
                photoName:photoName
            
            }
          
    
            // create a new object with the model we created earlier
            var newOrder = new Order(pageData); 
            newOrder.save(); // save into MongoDB
    
            res.render('confirmation', pageData);
    
        }
    
      
    });
    
// render the signin form
myApp.get('/signin',function(req, res){
    res.render('signin'); // will render views/signin.ejs
});



// signin process
myApp.post('/signinprocess', function(req, res){
    // fetch input
    var username = req.body.username;
    var password = req.body.password;

    // find in database 
    AdminUser.findOne({username: username, password: password}).exec(function(err, adminuser){
        
        if(adminuser){ // would be true if there is data returned in adminuser
            // save in session
            req.session.username = adminuser.username;
            req.session.loggedIn = true;
            res.redirect('/login');
        }
        else{
      
            var pageData = {
                error : 'Login details not correct'
            }
            res.render('signin', pageData);
        }
    });
});

//show all the docs in a table
myApp.get('/login',function(req,res){

    
    
    if(req.session.loggedIn){

        Order.find({}).exec(function(err,orders){
 
            var pageData={
                orders:orders
            }
            res.render('login',pageData);
        
           });
    }

    else{
        
        res.redirect('/login');
    }

    
    
 });

// unqiue card - :id helps to make it dynamic - view a selected item
myApp.get('/view/:id', function(req,res){

    if(req.session.loggedIn){
        var id= req.params.id;
      
        Order.findOne({_id:id}).exec(function (err,order){
            var pageData={
                name: order.name,
                email: order.email,
                photoName: order.photoName,
                mytextarea:order.mytextarea

            }
       
            res.render('displayView',pageData);
        });

    }
    else{
        res.redirect('/login');
    }

   
})

// unique card...edit

myApp.get('/displayEdit/:id', function(req,res){


    if(req.session.loggedIn){
        var id= req.params.id;
  
    Order.findOne({_id:id}).exec(function(err, order){
        var pageData={
          name: order.name,
          email:order.email,
          photoName:order.photoName,
          mytextarea:order.mytextarea,
          id:id // here we send id to displayEdit 

        }
        res.render('displayEdit',pageData);
        // from here it will later go to editprocess
      

    });

    }

    else{
        res.redirect('/login');
    }
    // all copied from /process ..extra add is id part


});



// editprocess


myApp.post('/editprocess', function(req,res){

    
    
    if(!req.session.loggedIn){
        res.redirect('/signin');

    }

    else{
        var id= req.body.id;
        var name = req.body.name; // the key here is from the name attribute not the id attribute
        var email = req.body.email;
        // fetch the image
        var photo = req.files.photo;
        // fetch the image name
        var photoName = req.files.photo.name;
        var imagePath = 'public/uploads/' + photoName;
        // store the image permamently at the defined path
        var mytextarea=req.body.mytextarea;
        photo.mv(imagePath);


        Order.findOne({_id:id}).exec(function(err, order){
        order.name=name,
        order.email=email,     
        order.photoName= photoName,
        order.mytextarea=mytextarea,
        order.save();

    });
    var pageData= {
        message:'Card updated'
    }

    res.render('displayMessage',pageData);
        
    }

});





// unique card .. deleted 
myApp.get('/displayDelete/:id',function(req, res){

    
    
    if(req.session.loggedIn){
        var id = req.params.id;
        
    
        Order.findByIdAndDelete({_id:id}).exec(function(err, order){

            var message = 'Item not found'; // be default assume card not found
            if(order){ // if card exists, then change the message
                message = 'The request has been been deleted successfully';
            }

            var pageData = {
                message: message
            }
            res.render('displayMessage', pageData);
        });
    }

    else{
        res.redirect('/login');
    }

});




// ------- application setup stuff -------
// do not push to production

myApp.get('/setup',function(req, res){
    var adminData = {
        username: 'admin',
        password: 'admin'
    }
    var newAdmin = new AdminUser(adminData);
    newAdmin.save();
    res.send('Done');
});





// listen at a port

myApp.listen(8080);
console.log('Open http://localhost:8080 in your browser');
